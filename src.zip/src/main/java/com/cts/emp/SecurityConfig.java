package com.cts.emp;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.context.annotation.Bean; 
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager; 
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter; 
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService; 
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; 
import org.springframework.security.crypto.password.PasswordEncoder; 
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.cts.emp.jwt.JwtAuthenticationEntryPoint;
import com.cts.emp.jwt.JwtRequestFilter;


/*class that allows customization to both WebSecurity and HttpSecurity.*/
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	
   @Autowired
   private JwtAuthenticationEntryPoint authenticationEntryPoint;
   
   @Autowired
   private UserDetailsService userDetailsService;
   
   @Autowired 
   private JwtRequestFilter filter;
   
   @Bean
   public PasswordEncoder passwordEncoder() {
      return new BCryptPasswordEncoder();
   }
   
   @Override
   protected void configure(AuthenticationManagerBuilder auth) throws Exception {
      auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
   }

   @Bean
   @Override
   public AuthenticationManager authenticationManagerBean() throws Exception {
      return super.authenticationManagerBean();
   }
   
   // /login and /register rest api url to be passed as a authorized request
   
   @Override
   protected void configure(HttpSecurity http) throws Exception {
	   //in Spring MVC the Spring adds a CSRF token to each generated view. 
	   //This token must be submitted to the server on every HTTP request 
	   //that modifies state (PATCH, POST, PUT and DELETE — not GET). 
	   //This protects our application against CSRF attacks since an attacker can't get this token from their own page.
	   
      http.csrf().disable()
      .authorizeRequests()
      .antMatchers("/register").permitAll() .antMatchers("/login").permitAll()
      .antMatchers(HttpMethod.OPTIONS, "/**").permitAll()
      .anyRequest().authenticated()
      .and()
      .exceptionHandling().authenticationEntryPoint(authenticationEntryPoint)
      .and()
      .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
      http.addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class);
      
//      httpSecurity.csrf().disable()
//		// dont authenticate this particular request
//		.authorizeRequests().antMatchers("/authenticate").
//		permitAll().antMatchers(HttpMethod.OPTIONS, "/**")
//		.permitAll().
//		// all other requests need to be authenticated
//		anyRequest().authenticated().and().
//		// make sure we use stateless session; session won't be used to
//		// store user's state.
//		exceptionHandling().authenticationEntryPoint(jwtAuthenticationEntryPoint).and().sessionManagement()
//		.sessionCreationPolicy(SessionCreationPolicy.STATELESS);

   }
   

	/*
	 * @Override protected void configure(HttpSecurity http) throws Exception {
	 * http.csrf().disable().authorizeRequests()
	 * .antMatchers("/register").permitAll() .antMatchers("/login").permitAll()
	 * .anyRequest().authenticated()
	 * .and().exceptionHandling().and().sessionManagement().sessionCreationPolicy(
	 * SessionCreationPolicy.IF_REQUIRED)
	 * .and().formLogin().loginPage("/login").loginProcessingUrl("/login")
	 * .defaultSuccessUrl("/index.html").failureUrl("/login?error")
	 * .and().logout().logoutUrl("/logout");
	 * 
	 * http.addFilterBefore(this.filter,
	 * UsernamePasswordAuthenticationFilter.class); }
	 */
   
}

/*
 import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

//1. Configure Spring Security to make use of in memory authentication. 
//2. Allow OPTIONS call. 
//3. These OPTIONS call are made by Angular application to Spring Boot application. 
//4. Also here we are disabling csrf. 
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	//Basic authentication is a simple authentication built using the HTTP protocol. 
	//When using this protocol the HTTP requests 
	//have Authorization header 
	//which has the word Basic followed by a space and base 64 encoded string username:password.
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable()
		.authorizeRequests()
		.antMatchers(HttpMethod.OPTIONS, "/**").permitAll()
		.anyRequest().authenticated()
				.and().httpBasic();
	}

	//every rest APi need this Basic Authentication
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("Kruthika").password("{noop}password").roles("USER");
	}
}


*/