package com.cts.emp.jwt;

import java.io.Serializable;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/*This class will be responsible for the 
 * creation and 
 * validation of tokens using io.jsonwebtoken.Jwts*/

@Component
public class JwtTokenUtil implements Serializable {

	private static final long serialVersionUID = 7008375124389347049L;

	// we want our token to be valid for 10 minutes after generation
	public static final long TOKEN_VALIDITY = 10 * 60 * 60;

	@Value("${secret}")
	private String jwtSecret;

	// while creating the token -
	// 1. Define claims of the token, like Issuer, Expiration, Subject, and the ID like payload
	// 2. Sign the JWT using the HS512 algorithm and secret key.
	public String generateJwtToken(UserDetails userDetails) {

		Map<String, Object> claims = new HashMap<>();
		//in token, username stored in subject
		return Jwts.builder().setClaims(claims)
				.setSubject(userDetails.getUsername())
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + TOKEN_VALIDITY * 1000))
				.signWith(SignatureAlgorithm.HS512, jwtSecret).compact();

	}

	// validate token return true or false
	// token username and userDetilas.username is same 
	// token not expire
	public Boolean validateJwtToken(String token, UserDetails userDetails) {
		String username = getUsernameFromToken(token);
		Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
		//if expired --> true
		//else -->false
		Boolean isTokenExpired = claims.getExpiration().before(new Date());
		//expire aagide illa or ade username token antha check madutte
		return (username.equals(userDetails.getUsername()) && !isTokenExpired);
	}

	// retrieve username from jwt token
	public String getUsernameFromToken(String token) {
		final Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
		return claims.getSubject();
	}
}