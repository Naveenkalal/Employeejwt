package com.cts.emp.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.emp.jwt.modal.JwtRequestModel;
import com.cts.emp.jwt.modal.JwtResponseModel;
import com.cts.emp.jwt.modal.UserDao;
import com.cts.emp.jwt.modal.UserDto;
import com.cts.emp.jwt.repository.UserRepository;


/*2 rest api endpoints, 
/register to persist new user in database 
and /login to generate token for that user.*/

@RestController
@CrossOrigin
public class JwtAuthenticationController {

	@Autowired
	private JwtUserDetailsService userDetailsService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	// generate token
	@PostMapping("/login")
	public ResponseEntity<?> createToken(@RequestBody JwtRequestModel request) throws Exception {
		try {
			// System.err.println("login "+request.getUsername()+" "+request.getPassword());
			// validate username and password for AUTHENTICATION
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));

			//valid user --> return true
			//else --> InvalidUserException 
		} catch (DisabledException e) {
			//if user is disabled
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			//bad credentials
			throw new Exception("INVALID_CREDENTIALS", e);
		}
		//GENERATE TOKEN
		// fetch UserDetails with userName
		final UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());

		// generate token for that userDetails
		final String jwtToken = jwtTokenUtil.generateJwtToken(userDetails);

		// System.err.println("Token generated");
		return ResponseEntity.ok(new JwtResponseModel(jwtToken));
	}

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;

	//new user
	@PostMapping("/register")
	public ResponseEntity<?> saveUser(@RequestBody UserDto user) throws Exception {
		//System.err.println("hi");

		//object stored in database
		UserDao newUser = new UserDao();
		newUser.setUsername(user.getUsername());
		newUser.setPassword(passwordEncoder.encode(user.getPassword()));
		// as password encoded only {username} sent as response
		return ResponseEntity.ok(userRepository.save(newUser));
	}

}