package com.cts.emp.jwt;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import io.jsonwebtoken.ExpiredJwtException;

/*For any REST API request this Filter class gets executed.
 * if request doesn't have token -- Generate Token process
 * else -- validate Token process
		It checks if the request has a valid JWT token. 
		If it has a valid JWT Token then it sets the Authentication in the context, 
			to specify that the current user is authenticated and provide access to reuest for user.*/

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

	// used during validating token
	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	// used during validation of token
	@Autowired
	private JwtUserDetailsService userDetailsService;

	//invoked once per request
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String tokenHeader = request.getHeader("Authorization");

		String username = null;

		String token = null;

		//checks whether request have Token .. 
		//if contains Token  -- validating token 
		//Bearer Token example below
		//Bearer eyJhbGciOiJIUzUx......
		if (tokenHeader != null && tokenHeader.startsWith("Bearer ")) {

			//VALIDATION OF JWT
			//System.err.println(tokenHeader);
			token = tokenHeader.substring(7);

			try {
				//to get userDetails by usernmae , first find username by token
				username = jwtTokenUtil.getUsernameFromToken(token);
			} catch (IllegalArgumentException e) {
				//wrong JWT
				System.out.println("Unable to get JWT Token");
			} catch (ExpiredJwtException e) {
				//expired JWT
				System.out.println("JWT Token has expired");
			}
		} else {
			System.out.println("Bearer String not found in token");
		}
		if (null != username && SecurityContextHolder.getContext().getAuthentication() == null) {

			//fetch the UserDetails from DB with username
			UserDetails userDetails = userDetailsService.loadUserByUsername(username);
			//validate the token by using method in JwtTokenUtil -- returns true or false
			if (jwtTokenUtil.validateJwtToken(token, userDetails)) {
				
				//after Valid token
				//set Authentication is context, so user can access any rest Api request
				UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());
				authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authenticationToken);
			}
		}
		filterChain.doFilter(request, response);
	}
}